#====NO 3====#
class Mahasiswa():
    """Calss mahasiswa yang dibangun dari Class Mahasiswa"""

    def __init__(self,nama,nim,kota,us ):
        """metode inisiasi ini menutupi metode inisiasi di class manusia"""
        self.nama = nama
        self.nim = nim
        self.kotaTinggal = kota
        self.uangSaku = us

    def __str__(self):
        s = self.nama + ", nim" + str(self.nim) \
            + ". Tinggal di" + self.tokaTinggal \
            + ". Uang saku RP" + str(self.uangSaku) \
            + ". tiap bulan"
        return s

    def ambilnama(self):
        return self.nama

    def amnilnim(self):
        return self.nim

    def ambiluangsaku(self):
        print( self.uangSaku)

    def ambilKota(self):
        print(self.kotaTinggal)

    def perbaruiKota(self, kotaBaru):
        self.kotaTinggal = kotaBaru

    def tambahUangsaku(self, tambahi):
        print(self.uangSaku + tambahi)



    def makan(self, s):
        """Metode ini menutupi metode makan nya class manusia
        mahsiswa klau makan sambil belajar."""
        print("saya baru saja makan ", s, "samnil belajar")
        self.keadaan = 'kenyang'


nama = (input("masukan nama :" ))
nim = (input("masukan nim :" ))
kota = (input("masukan kota :" ))
us =(input("masukan Uang saku :" ))

zulfa = Mahasiswa(nama, nim,kota, us)
print(zulfa)

