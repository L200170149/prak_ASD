class Manusia(object):
    """Class 'manusia' dengan inisasi 'nama' """
    keadaan = 'lapar'

    def __init__(self, nama):
        self.nama = nama
    def ucapanSalam(self):
        print("salam, namaku", self.nama)
    def makan(self, s):
        print ("saya baru saja makan", s)
        self.keadaan = "kenyang"

    def olahraga(self,k):
        print ("saya baru saja latihan", k)
        self.keadaan = "lapar"
    def mengalianDenganDua(self,n):
        return n*2

p1 = Manusia("sri")
p1.ucapanSalam()

#====NO 6====#
class siswaSMA(Manusia):
    def __init__(self, nama, tahunlahir):
        self.nama = nama
        self.tahunlahir = tahunlahir

    def hitungUmur(self):
        print (2019 - self.tahunlahir)

rohman = siswaSMA("rohman", 1999)
rohman.hitungUmur()