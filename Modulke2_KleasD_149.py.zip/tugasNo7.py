#====NO 7====#
from tugasNo2 import Mahasiswa


class MhsTIF(Mahasiswa):
    def katakanPy(self):
        print("python is cool")

falah = MhsTIF("falah", "l1010", "solo", "100") #membuat object yang dari instance Mahasiswa
falah.ambilKota() #instance dari class mahasiswa
falah.ambiluangsaku() #instance dari class mahasiswa
falah.katakanPy() #method dari class MhsTIF