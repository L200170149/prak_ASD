#====NO 1====#
class pesan():

    def __init__(self,kata):
        self.kata = kata


    def apakahPesanTerkandung(self,x):
        if x in self.kata :
          print("True")
        else:
            print("false")
    def menghitungKonsonan(self):
        vokal = "aiueoAIUEO"
        hitung = 0
        for i in self.kata:
            if i not in vokal:
                hitung +=1
        print(hitung)

    def menghitungVokal(self):
        vokal = "aiueoAIUEO"
        hitung = 0
        for i in self.kata:
            if i in vokal:
                hitung += 1
        print(hitung)


p1 = pesan("indonesia tanah air ku guys")

p1.apakahPesanTerkandung("airku")
p1.menghitungKonsonan()
p1.menghitungVokal()